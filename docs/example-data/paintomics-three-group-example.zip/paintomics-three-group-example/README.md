# PaintOmics three-group example (mouse, RNA-seq + lipidomics)

A small, **simulated** experiment with three groups -- `Ctrl`, `TrtA`, `TrtB`,
4 animals each -- for learning how to run a multi-group analysis in
PaintOmics (https://paintomics.org). Gene and compound identifiers and the
pathway structure are real (mouse KEGG); only the numbers are simulated, with
a known signal planted so you can check that the analysis finds it.

## What is in here

| Path | What it is |
| --- | --- |
| `raw_data/rnaseq_counts.tsv` | Raw RNA-seq counts, 15,401 genes x 12 samples (versioned Ensembl ids, as GENCODE gives them) |
| `raw_data/lipidomics_intensities.tsv` | 133 lipid species x 12 samples (peak intensities; `NA` = not detected) |
| `raw_data/lipid_class_to_kegg.tsv` | Which KEGG compound each lipid class / molecule is drawn as |
| `raw_data/sample_sheet.tsv` | Sample -> group |
| `make_paintomics_inputs.R` | DESeq2 (RNA-seq) + limma (lipids) -> the four PaintOmics files |
| `paintomics_inputs/` | The script's output, ready to upload (if you want to skip R) |
| `PLANTED_SIGNAL.tsv` | The answer key: which pathways were made to change, and in which group |

## Run it

```
# once: install.packages("BiocManager"); BiocManager::install(c("DESeq2", "limma"))
Rscript make_paintomics_inputs.R
```

Tested with R 4.6.0, DESeq2 1.52.0 and limma (Bioconductor 3.23). It writes
`paintomics_inputs/` and prints how many genes and lipids are significant per
contrast (230 / 315 / 398 genes and 10 / 9 / 11 lipid compounds at FDR < 0.05).

Then upload the four files on paintomics.org (organism *Mus musculus*):

| PaintOmics card | Data file | Relevant features file |
| --- | --- | --- |
| Gene expression | `rnaseq_values.tsv` | `rnaseq_relevant.tsv` |
| Metabolomics | `lipids_values.tsv` | `lipids_relevant.tsv` |

The step-by-step tutorial with screenshots explains every screen.

## The planted signal (what you should find)

| Pathway (KEGG) | Changed in | Direction |
| --- | --- | --- |
| PPAR signaling pathway, Fatty acid degradation | TrtA **and** TrtB | up |
| Steroid biosynthesis, Terpenoid backbone biosynthesis, Cholesterol metabolism | TrtA only | down |
| TNF signaling pathway, NF-kappa B signaling pathway | TrtB only | up |

Lipids follow the same story: triacylglycerol, diacylglycerol, free fatty
acids 16:0 / 18:1 and acylcarnitines up in both treatments; cholesterol,
cholesterol esters, lanosterol, desmosterol and squalene down in TrtA only;
ceramide, sphingosine, sphingosine-1-phosphate, arachidonic acid, PGE2 and
LTB4 up in TrtB only.

## How the data were simulated

RNA-seq counts are negative-binomial (DESeq2-like mean-dispersion trend,
random size factors). In each planted pathway 60% of the member genes respond
with a log2 fold change of about 1.3; 2% of all other genes get a random
change, so the significant lists are not pathway-pure. Lipid species are
log-normal with a per-animal, per-class biological effect, and the faintest
species have about 12% missing values. Because the data are simulated, no
biological conclusion should be drawn from them.
