#!/usr/bin/env Rscript
# =============================================================================
#  From a three-group experiment to PaintOmics input files
# =============================================================================
#
#  Input  (folder raw_data/):
#    rnaseq_counts.tsv          raw RNA-seq counts, genes x samples
#    lipidomics_intensities.tsv lipid species x samples (peak areas / intensities)
#    lipid_class_to_kegg.tsv    which KEGG compound each lipid class is drawn as
#    sample_sheet.tsv           sample -> group
#
#  Output (folder paintomics_inputs/), ready to upload:
#    rnaseq_values.tsv      one log2 fold-change column per contrast
#    rnaseq_relevant.tsv    one list of significant genes per contrast
#    lipids_values.tsv      one log2 fold-change column per contrast
#    lipids_relevant.tsv    one list of significant lipids per contrast
#
#  PaintOmics paints one value per feature per "condition". With three groups
#  you therefore give it one column per COMPARISON (contrast) you care about,
#  and a relevant-features file with one column per contrast, so that every
#  pathway gets its own p-value for each comparison.
#
#  Requirements: R >= 4.2 with DESeq2 and limma (Bioconductor):
#    install.packages("BiocManager"); BiocManager::install(c("DESeq2", "limma"))
#
#  Run:  Rscript make_paintomics_inputs.R      (from the folder holding raw_data/)
# =============================================================================

suppressPackageStartupMessages({
  library(DESeq2)
  library(limma)
})

# ---- 1. Settings: the only part you normally edit ---------------------------

raw_dir <- "raw_data"
out_dir <- "paintomics_inputs"

reference_group <- "Ctrl"                # the group every fold change is measured against
group_levels    <- c("Ctrl", "TrtA", "TrtB")

# One entry per column PaintOmics will show.  name = c(numerator, denominator)
# Three groups give three possible pairwise comparisons; keep the ones you need.
contrasts <- list(
  TrtA_vs_Ctrl = c("TrtA", "Ctrl"),
  TrtB_vs_Ctrl = c("TrtB", "Ctrl"),
  TrtB_vs_TrtA = c("TrtB", "TrtA")
)

fdr_cutoff <- 0.05          # adjusted p-value for "relevant" (significant)
min_abs_lfc <- 0            # optional extra filter on |log2FC|, e.g. log2(1.5)

# ---- 2. Small helpers ---------------------------------------------------------

read_table <- function(path, ...) {
  # Tab-separated, header row, nothing turned into factors, and NO locale magic:
  # numbers must use a dot as the decimal mark.
  read.delim(path, check.names = FALSE, stringsAsFactors = FALSE,
             na.strings = c("NA", "NaN", "", "n.d.", "nd"), ...)
}

write_values <- function(lfc_matrix, id_header, path) {
  # PaintOmics values file: '#' on the header row, one column per contrast,
  # dot decimals, no quotes.  The column names become the condition labels.
  out <- data.frame(id = rownames(lfc_matrix),
                    format(round(lfc_matrix, 4), nsmall = 4, trim = TRUE,
                           scientific = FALSE),
                    check.names = FALSE)
  colnames(out)[1] <- paste0("#", id_header)
  write.table(out, path, sep = "\t", quote = FALSE, row.names = FALSE)
}

write_relevant <- function(id_lists, path) {
  # Per-contrast relevant-features file: a PLAIN header (no '#') with the same
  # contrast names as the values file, then one column of ids per contrast,
  # padded with empty cells because the lists have different lengths.
  height <- max(1, lengths(id_lists))
  padded <- lapply(id_lists, function(ids) c(sort(ids), rep("", height - length(ids))))
  out <- as.data.frame(padded, check.names = FALSE, stringsAsFactors = FALSE)
  write.table(out, path, sep = "\t", quote = FALSE, row.names = FALSE)
}

dir.create(out_dir, showWarnings = FALSE)

samples <- read_table(file.path(raw_dir, "sample_sheet.tsv"))
samples$group <- factor(samples$group, levels = group_levels)
stopifnot("every sample needs one of group_levels" = !anyNA(samples$group))
samples$group <- relevel(samples$group, ref = reference_group)

# ---- 3. RNA-seq: DESeq2 -------------------------------------------------------

counts <- read_table(file.path(raw_dir, "rnaseq_counts.tsv"))

# Ensembl ids from GENCODE carry a version suffix (ENSMUSG00000000001.5).
# PaintOmics matches ids exactly, so strip it -- and add up the rare rows that
# collapse onto the same gene once the suffix is gone.
gene_ids <- sub("\\.[0-9]+$", "", counts[[1]])
count_matrix <- as.matrix(counts[, samples$sample])        # also checks sample names
storage.mode(count_matrix) <- "integer"
count_matrix <- rowsum(count_matrix, gene_ids)
stopifnot("counts must not be negative or missing" = !anyNA(count_matrix),
          all(count_matrix >= 0))

# Drop genes that are essentially not expressed (>= 10 reads in at least as
# many samples as the smallest group).  They cannot be tested and only add noise.
smallest_group <- min(table(samples$group))
count_matrix <- count_matrix[rowSums(count_matrix >= 10) >= smallest_group, ]

dds <- DESeqDataSetFromMatrix(count_matrix, colData = samples, design = ~ group)
dds <- DESeq(dds, quiet = TRUE)

rna <- lapply(contrasts, function(ct)
  results(dds, contrast = c("group", ct[1], ct[2]), alpha = fdr_cutoff))

rna_lfc <- sapply(rna, function(r) r$log2FoldChange)
rownames(rna_lfc) <- rownames(dds)
rna_lfc <- rna_lfc[complete.cases(rna_lfc), , drop = FALSE]   # no empty cells allowed

rna_relevant <- lapply(rna, function(r) {
  hit <- !is.na(r$padj) & r$padj < fdr_cutoff & abs(r$log2FoldChange) >= min_abs_lfc
  intersect(rownames(r)[hit], rownames(rna_lfc))
})

write_values(rna_lfc, "gene_id", file.path(out_dir, "rnaseq_values.tsv"))
write_relevant(rna_relevant, file.path(out_dir, "rnaseq_relevant.tsv"))

# ---- 4. Lipidomics: species -> KEGG class, then limma -------------------------

lipids <- read_table(file.path(raw_dir, "lipidomics_intensities.tsv"))
class_map <- read_table(file.path(raw_dir, "lipid_class_to_kegg.tsv"))

intensity <- as.matrix(lipids[, samples$sample])
stopifnot("intensities must be numeric -- check the decimal mark" = is.numeric(intensity))
intensity[intensity <= 0] <- NA                                  # zero = not detected

# Keep a species only if it was detected in most samples of at least one group;
# fill the remaining gaps with half of that species' smallest observed value
# (a common, conservative stand-in for "below the detection limit").
detected_in_a_group <- sapply(levels(samples$group), function(g)
  rowMeans(!is.na(intensity[, samples$group == g, drop = FALSE])) >= 0.75)
keep <- rowSums(detected_in_a_group) > 0
intensity <- intensity[keep, , drop = FALSE]
lipid_class <- lipids$class[keep]
half_min <- apply(intensity, 1, min, na.rm = TRUE) / 2
missing <- which(is.na(intensity), arr.ind = TRUE)
intensity[missing] <- half_min[missing[, "row"]]

# KEGG draws lipids at class level (one "Phosphatidylcholine" node, not one per
# PC species), so species are summed into their class.  This is also why
# species-level ChEBI or SwissLipids ids find nothing in KEGG.
unmapped <- setdiff(unique(lipid_class), class_map$class)
if (length(unmapped)) warning("classes with no KEGG id, dropped: ", toString(unmapped))
class_sum <- rowsum(intensity[lipid_class %in% class_map$class, , drop = FALSE],
                    lipid_class[lipid_class %in% class_map$class])
rownames(class_sum) <- class_map$kegg_id[match(rownames(class_sum), class_map$class)]
class_sum <- rowsum(class_sum, rownames(class_sum))   # two classes, one KEGG id -> one row

log_lipids <- log2(class_sum)
design <- model.matrix(~ 0 + group, data = samples)
colnames(design) <- levels(samples$group)
contrast_matrix <- makeContrasts(
  contrasts = sapply(contrasts, function(ct) paste(ct[1], "-", ct[2])),
  levels = design)
colnames(contrast_matrix) <- names(contrasts)
fit <- eBayes(contrasts.fit(lmFit(log_lipids, design), contrast_matrix))

lip <- lapply(names(contrasts), function(n)
  topTable(fit, coef = n, number = Inf, sort.by = "none"))
names(lip) <- names(contrasts)
lip_lfc <- sapply(lip, function(t) t$logFC)
rownames(lip_lfc) <- rownames(log_lipids)
lip_relevant <- lapply(lip, function(t)
  rownames(t)[t$adj.P.Val < fdr_cutoff & abs(t$logFC) >= min_abs_lfc])

write_values(lip_lfc, "kegg_id", file.path(out_dir, "lipids_values.tsv"))
write_relevant(lip_relevant, file.path(out_dir, "lipids_relevant.tsv"))

# ---- 5. Report ------------------------------------------------------------------

cat("\nWritten to ", normalizePath(out_dir), "/\n", sep = "")
cat(sprintf("  RNA-seq : %5d genes, %d contrasts\n", nrow(rna_lfc), ncol(rna_lfc)))
cat(sprintf("  Lipids  : %5d KEGG compounds from %d species\n", nrow(lip_lfc), nrow(intensity)))
cat("\nSignificant features per contrast (FDR <", fdr_cutoff, ")\n")
print(rbind(genes = lengths(rna_relevant), lipids = lengths(lip_relevant)))
